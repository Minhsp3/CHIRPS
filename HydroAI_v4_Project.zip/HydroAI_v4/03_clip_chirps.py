import geopandas as gpd
import numpy as np
import pandas as pd
import xarray as xr
from rasterio.features import geometry_mask
from rasterio.transform import from_bounds
from config import BASIN_DIR, BASIN_NAMES, CHIRPS_PATTERN, DAILY_DIR, END_DATE, OUTPUT_DIR, START_DATE

def find_name(ds, candidates):
    names = set(ds.coords) | set(ds.dims)
    lookup = {n.lower(): n for n in names}
    for c in candidates:
        if c in names: return c
        if c.lower() in lookup: return lookup[c.lower()]
    raise KeyError(f"Không tìm thấy tọa độ {candidates}")

def make_mask(da, basin, lat_name, lon_name):
    lat, lon = da[lat_name].values, da[lon_name].values
    dx, dy = abs(float(lon[1]-lon[0])), abs(float(lat[1]-lat[0]))
    transform = from_bounds(float(lon.min())-dx/2, float(lat.min())-dy/2,
                            float(lon.max())+dx/2, float(lat.max())+dy/2,
                            len(lon), len(lat))
    mask = geometry_mask([g.__geo_interface__ for g in basin.geometry],
                         out_shape=(len(lat), len(lon)), transform=transform,
                         invert=True, all_touched=True)
    if lat[0] < lat[-1]: mask = np.flipud(mask)
    return xr.DataArray(mask, coords={lat_name: da[lat_name], lon_name: da[lon_name]}, dims=(lat_name, lon_name))

def process_one(rain, basin_id, lat_name, lon_name):
    shp = BASIN_DIR / f"{BASIN_NAMES[basin_id]}.shp"
    if not shp.exists():
        raise FileNotFoundError(f"Thiếu {shp}; chạy 02_create_basin.py trước.")
    basin = gpd.read_file(shp).to_crs("EPSG:4326")
    minx, miny, maxx, maxy = basin.total_bounds
    lat = rain[lat_name]
    lat_slice = slice(miny-.1, maxy+.1) if float(lat[0]) < float(lat[-1]) else slice(maxy+.1, miny-.1)
    sub = rain.sel({lon_name: slice(minx-.1, maxx+.1), lat_name: lat_slice})
    mask = make_mask(sub, basin, lat_name, lon_name)
    valid = sub.where(sub >= 0).where(mask)
    weights = np.cos(np.deg2rad(valid[lat_name]))
    mean = valid.weighted(weights).mean(dim=[lat_name, lon_name], skipna=True)
    df = mean.compute().to_series().reset_index()
    df.columns = ["Date", "Rain_Basin_mm"]
    df["Date"] = pd.to_datetime(df["Date"])
    df["Basin_ID"] = basin_id
    df["Rain_Basin_mm"] = df["Rain_Basin_mm"].round(2)
    for w in [3,7,15,30,90]: df[f"Rain_{w}d_mm"] = df["Rain_Basin_mm"].rolling(w, min_periods=1).sum().round(2)
    for lag in [1,2,3,5,7,14,30]: df[f"Rain_Lag{lag}_mm"] = df["Rain_Basin_mm"].shift(lag).round(2)
    df["Year"] = df["Date"].dt.year
    df["Month"] = df["Date"].dt.month
    df["Month_sin"] = np.sin(2*np.pi*df["Month"]/12)
    df["Month_cos"] = np.cos(2*np.pi*df["Month"]/12)
    return df

def clip_all():
    files = sorted(DAILY_DIR.glob(CHIRPS_PATTERN))
    if not files: raise FileNotFoundError(f"Không có CHIRPS Daily trong {DAILY_DIR}")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Tìm thấy {len(files)} file CHIRPS.")
    ds = xr.open_mfdataset([str(f) for f in files], combine="by_coords", chunks="auto",
                           engine="netcdf4", parallel=False, data_vars="minimal",
                           coords="minimal", compat="override")
    try:
        latn = find_name(ds, ["latitude","lat","y"])
        lonn = find_name(ds, ["longitude","lon","x"])
        timen = find_name(ds, ["time","date"])
        precip = "precip" if "precip" in ds.data_vars else list(ds.data_vars)[0]
        rain = ds[precip].sel({timen: slice(START_DATE, END_DATE)})
        results = {}
        for bid in BASIN_NAMES:
            print(f"Trích mưa {bid}...")
            df = process_one(rain, bid, latn, lonn)
            results[bid] = df
            df.to_csv(OUTPUT_DIR/f"CHIRPS_{bid}_daily.csv", index=False, encoding="utf-8-sig")
        pd.concat(results.values(), ignore_index=True).to_csv(OUTPUT_DIR/"CHIRPS_All_Basins_daily.csv", index=False, encoding="utf-8-sig")
        return results
    finally:
        ds.close()

if __name__ == "__main__": clip_all()

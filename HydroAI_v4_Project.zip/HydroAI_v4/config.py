from pathlib import Path

BASE_DIR = Path(r"D:\VScode\CHIRPS")
DAILY_DIR = BASE_DIR / "Daily"
DEM_DIR = BASE_DIR / "dem"
BASIN_DIR = BASE_DIR / "luu_vuc"
HYDROLOGY_DIR = BASE_DIR / "hydrology"
OUTPUT_DIR = BASE_DIR / "output"
MODEL_DIR = BASE_DIR / "models"

CHIRPS_PATTERN = "chirps-v2.0.*.days_p05.nc"
OUTLETS = {
    "BTS": (108.06069243337487, 12.245219147474575),
    "BK": (107.933552, 12.527364),
    "SP3": (107.88876981346154, 12.754378941554707),
}
BASIN_NAMES = {"BTS": "Buon_Tua_Srah", "BK": "Buon_Kuop", "SP3": "Srepok_3"}
DEM_BOUNDS = (107.0, 11.2, 109.0, 13.4)  # west, south, east, north
DEM_FILE = DEM_DIR / "srtm30_srepok.tif"
START_DATE = "2021-01-01"
END_DATE = "2026-12-31"
STREAM_ACC_THRESHOLD = 500
HYDROLOGY_FILES = {
    "BTS": HYDROLOGY_DIR / "BTS_daily.xlsx",
    "BK": HYDROLOGY_DIR / "BK_daily.xlsx",
    "SP3": HYDROLOGY_DIR / "SP3_daily.xlsx",
}
TARGET_COLUMN = "Q_in_m3s"

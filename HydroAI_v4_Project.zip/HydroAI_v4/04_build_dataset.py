import pandas as pd
from config import BASIN_NAMES, HYDROLOGY_FILES, OUTPUT_DIR

ALIASES = {"ngay":"Date","date":"Date","thoi_gian":"Date","q_ve":"Q_in_m3s","luu_luong_ve":"Q_in_m3s","q_in_m3s":"Q_in_m3s","muc_nuoc":"WaterLevel_m","dung_tich":"Storage_Mm3","san_luong":"Generation_MWh"}

def norm(name):
    key = str(name).strip().lower().replace(" ","_").replace("-","_").replace("/","_")
    return ALIASES.get(key, str(name).strip())

def read_hydro(path):
    df = pd.read_csv(path) if path.suffix.lower()==".csv" else pd.read_excel(path)
    df = df.rename(columns={c:norm(c) for c in df.columns})
    if "Date" not in df.columns: raise KeyError(f"{path.name} thiếu cột Date/Ngày")
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce", dayfirst=True).dt.normalize()
    return df.dropna(subset=["Date"])

def build_one(bid):
    rain_file = OUTPUT_DIR/f"CHIRPS_{bid}_daily.csv"
    if not rain_file.exists(): raise FileNotFoundError(f"Thiếu {rain_file}")
    rain = pd.read_csv(rain_file, parse_dates=["Date"])
    hp = HYDROLOGY_FILES[bid]
    df = rain.merge(read_hydro(hp), on="Date", how="left") if hp.exists() else rain.copy()
    if "Q_in_m3s" in df.columns:
        q = pd.to_numeric(df["Q_in_m3s"], errors="coerce")
        for lag in [1,2,3,7,14,30]: df[f"Q_Lag{lag}"] = q.shift(lag)
        for w in [3,7,15,30]: df[f"Q_{w}d_mean"] = q.rolling(w, min_periods=1).mean()
    df["Basin_ID"] = bid
    return df.sort_values("Date")

def build_all():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    results = {bid:build_one(bid) for bid in BASIN_NAMES}
    for bid,df in results.items(): df.to_csv(OUTPUT_DIR/f"HydroAI_{bid}_dataset.csv", index=False, encoding="utf-8-sig")
    all_df = pd.concat(results.values(), ignore_index=True)
    all_df.to_csv(OUTPUT_DIR/"HydroAI_All_Basins_dataset.csv", index=False, encoding="utf-8-sig")
    with pd.ExcelWriter(OUTPUT_DIR/"HydroAI_Dataset_v4.xlsx", engine="openpyxl") as w:
        all_df.to_excel(w, sheet_name="All_Basins", index=False)
        for bid,df in results.items(): df.to_excel(w, sheet_name=f"{bid}_Daily", index=False)
    print("Đã tạo HydroAI_Dataset_v4.xlsx")
    return results

if __name__ == "__main__": build_all()

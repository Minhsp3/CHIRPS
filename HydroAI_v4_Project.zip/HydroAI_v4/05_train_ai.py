import json, joblib, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from config import BASIN_NAMES, MODEL_DIR, OUTPUT_DIR, TARGET_COLUMN

EXCLUDE = {"Date","Basin_ID",TARGET_COLUMN,"WaterLevel_m","Storage_Mm3","Generation_MWh"}

def train_one(bid):
    f = OUTPUT_DIR/f"HydroAI_{bid}_dataset.csv"
    if not f.exists(): raise FileNotFoundError(f"Thiếu {f}")
    df = pd.read_csv(f, parse_dates=["Date"])
    if TARGET_COLUMN not in df.columns: raise KeyError(f"{bid} chưa có {TARGET_COLUMN}")
    features = [c for c in df.select_dtypes(include=[np.number]).columns if c not in EXCLUDE]
    model_df = df[["Date",TARGET_COLUMN]+features].dropna(subset=[TARGET_COLUMN])
    if len(model_df) < 200: raise ValueError(f"{bid}: cần tối thiểu 200 ngày có lưu lượng")
    split = int(len(model_df)*0.8)
    tr, te = model_df.iloc[:split], model_df.iloc[split:]
    model = HistGradientBoostingRegressor(learning_rate=.05, max_iter=500, max_leaf_nodes=31, l2_regularization=1, random_state=42)
    model.fit(tr[features], tr[TARGET_COLUMN])
    pred = model.predict(te[features])
    metrics = {"Basin_ID":bid,"MAE":float(mean_absolute_error(te[TARGET_COLUMN],pred)),"RMSE":float(mean_squared_error(te[TARGET_COLUMN],pred)**.5),"R2":float(r2_score(te[TARGET_COLUMN],pred)),"Features":features}
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model":model,"features":features,"target":TARGET_COLUMN}, MODEL_DIR/f"model_{bid}.joblib")
    with open(MODEL_DIR/f"metrics_{bid}.json","w",encoding="utf-8") as fp: json.dump(metrics,fp,ensure_ascii=False,indent=2)
    out = te[["Date",TARGET_COLUMN]].copy(); out["Q_Predicted_m3s"] = pred
    out.to_csv(OUTPUT_DIR/f"Backtest_{bid}.csv",index=False,encoding="utf-8-sig")
    print(f"{bid}: MAE={metrics['MAE']:.2f}; RMSE={metrics['RMSE']:.2f}; R²={metrics['R2']:.3f}")
    return metrics

def train_all():
    rows=[]
    for bid in BASIN_NAMES:
        try: rows.append(train_one(bid))
        except Exception as e: print(f"Không huấn luyện {bid}: {e}")
    if rows: pd.DataFrame([{k:v for k,v in r.items() if k!='Features'} for r in rows]).to_excel(OUTPUT_DIR/"Model_Metrics.xlsx",index=False)

if __name__ == "__main__": train_all()

import argparse, subprocess, sys
from pathlib import Path
from config import BASIN_DIR, DEM_DIR, MODEL_DIR, OUTPUT_DIR

STEPS = [
    ("01_download_dem.py","Tải DEM SRTM"),
    ("02_create_basin.py","Phân định 03 lưu vực"),
    ("03_clip_chirps.py","Trích CHIRPS Daily"),
    ("04_build_dataset.py","Xây dựng Dataset"),
    ("05_train_ai.py","Huấn luyện AI"),
    ("06_forecast.py","Dự báo lưu lượng"),
]

def ensure_dirs():
    for p in [DEM_DIR,BASIN_DIR,OUTPUT_DIR,MODEL_DIR]: p.mkdir(parents=True,exist_ok=True)

def run_step(i):
    script = Path(__file__).parent/STEPS[i-1][0]
    print("\n"+"="*78); print(f"BƯỚC {i}: {STEPS[i-1][1]}"); print("="*78)
    subprocess.run([sys.executable,str(script)],check=True,cwd=script.parent)

def main():
    parser=argparse.ArgumentParser(description="HydroAI v4.0")
    parser.add_argument("--only",type=int,choices=range(1,7))
    parser.add_argument("--start-step",type=int,default=1,choices=range(1,7))
    parser.add_argument("--end-step",type=int,default=6,choices=range(1,7))
    a=parser.parse_args(); ensure_dirs()
    if a.only: run_step(a.only)
    else:
        for i in range(a.start_step,a.end_step+1): run_step(i)
    print("\nHOÀN THÀNH HYDROAI v4.0")

if __name__ == "__main__":
    try: main()
    except Exception as e:
        print("\nCHƯƠNG TRÌNH DỪNG DO LỖI:"); print(e); sys.exit(1)

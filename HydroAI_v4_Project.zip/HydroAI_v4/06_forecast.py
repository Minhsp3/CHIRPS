import json, joblib, numpy as np, pandas as pd
from config import BASIN_NAMES, MODEL_DIR, OUTPUT_DIR

def forecast_one(bid):
    mf = MODEL_DIR/f"model_{bid}.joblib"
    if not mf.exists(): raise FileNotFoundError(f"Thiếu {mf}")
    bundle = joblib.load(mf); model, features = bundle["model"], bundle["features"]
    df = pd.read_csv(OUTPUT_DIR/f"HydroAI_{bid}_dataset.csv", parse_dates=["Date"])
    valid = df.dropna(subset=features).copy()
    if valid.empty: raise ValueError("Không có dòng đủ dữ liệu")
    valid["Q_P50_m3s"] = model.predict(valid[features])
    rmse = 0.0
    metric = MODEL_DIR/f"metrics_{bid}.json"
    if metric.exists():
        with open(metric,encoding="utf-8") as fp: rmse=float(json.load(fp).get("RMSE",0))
    valid["Q_P10_m3s"] = np.maximum(0, valid["Q_P50_m3s"]-1.282*rmse)
    valid["Q_P90_m3s"] = valid["Q_P50_m3s"]+1.282*rmse
    out = valid[["Date","Basin_ID","Q_P10_m3s","Q_P50_m3s","Q_P90_m3s"]]
    out.to_csv(OUTPUT_DIR/f"Forecast_{bid}.csv",index=False,encoding="utf-8-sig")
    return out

def forecast_all():
    frames=[]
    for bid in BASIN_NAMES:
        try: frames.append(forecast_one(bid))
        except Exception as e: print(f"Không dự báo {bid}: {e}")
    if not frames: raise RuntimeError("Không dự báo được lưu vực nào")
    result=pd.concat(frames,ignore_index=True)
    result.to_excel(OUTPUT_DIR/"HydroAI_Forecast_All.xlsx",index=False)
    print("Đã xuất HydroAI_Forecast_All.xlsx")

if __name__ == "__main__": forecast_all()

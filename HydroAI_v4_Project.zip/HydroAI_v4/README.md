# HydroAI v4.0

## Cài đặt
```powershell
cd D:\VScode\CHIRPS
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Chép các file dự án vào
`D:\VScode\CHIRPS\`

## Chạy từng bước
```powershell
python hydroai.py --only 1
python hydroai.py --only 2
python hydroai.py --only 3
python hydroai.py --only 4
python hydroai.py --only 5
python hydroai.py --only 6
```

## Chạy từ bước 1 đến bước 4
```powershell
python hydroai.py --start-step 1 --end-step 4
```

## Lưu ý
- Sau bước 2, mở các shapefile trong QGIS để kiểm tra ranh giới lưu vực.
- Nếu outlet bị snap sai nhánh sông, chỉnh `STREAM_ACC_THRESHOLD` trong `config.py`.
- Bước 5 cần file lưu lượng ngày có cột `Date` và `Q_in_m3s`.
- P10/P90 hiện là khoảng sơ bộ dựa trên RMSE backtest, chưa phải dự báo xác suất hiệu chỉnh đầy đủ.

from pathlib import Path
import geopandas as gpd
import numpy as np
import rasterio
from rasterio.features import shapes
from shapely.geometry import shape
from pysheds.grid import Grid
from config import BASIN_DIR, BASIN_NAMES, DEM_FILE, OUTLETS, STREAM_ACC_THRESHOLD

def mask_to_polygon(mask, transform, crs):
    geoms = [shape(g) for g, v in shapes(mask.astype("uint8"), mask=mask, transform=transform) if int(v) == 1]
    if not geoms:
        raise RuntimeError("Không tạo được polygon lưu vực.")
    gdf = gpd.GeoDataFrame(geometry=geoms, crs=crs).dissolve().explode(index_parts=False).reset_index(drop=True)
    gdf["geometry"] = gdf.geometry.buffer(0)
    return gdf

def delineate_one(basin_id: str) -> Path:
    if not DEM_FILE.exists():
        raise FileNotFoundError(f"Thiếu DEM: {DEM_FILE}. Chạy 01_download_dem.py trước.")
    BASIN_DIR.mkdir(parents=True, exist_ok=True)
    lon, lat = OUTLETS[basin_id]
    print(f"Phân định lưu vực {basin_id}...")
    grid = Grid.from_raster(str(DEM_FILE))
    dem = grid.read_raster(str(DEM_FILE))
    dem = grid.resolve_flats(grid.fill_depressions(grid.fill_pits(dem)))
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)
    sx, sy = grid.snap_to_mask(acc > STREAM_ACC_THRESHOLD, (lon, lat))
    catch = grid.catchment(x=sx, y=sy, fdir=fdir, dirmap=dirmap, xytype="coordinate")
    with rasterio.open(DEM_FILE) as src:
        basin = mask_to_polygon(np.asarray(catch, dtype=bool), src.transform, src.crs)
    basin = basin.to_crs("EPSG:4326")
    basin["Basin_ID"] = basin_id
    basin["OutletLon"] = lon
    basin["OutletLat"] = lat
    basin["SnapLon"] = sx
    basin["SnapLat"] = sy
    out = BASIN_DIR / f"{BASIN_NAMES[basin_id]}.shp"
    basin.to_file(out, driver="ESRI Shapefile", encoding="UTF-8")
    area = basin.to_crs("EPSG:32648").area.sum() / 1_000_000
    print(f"Outlet snap: {sx:.6f}, {sy:.6f}; diện tích sơ bộ: {area:.2f} km²")
    print(f"Đã xuất: {out}")
    return out

def create_all():
    return {bid: delineate_one(bid) for bid in OUTLETS}

if __name__ == "__main__":
    create_all()

from pathlib import Path
from config import DEM_BOUNDS, DEM_FILE

def download_dem(output_file: Path = DEM_FILE, force: bool = False) -> Path:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    if output_file.exists() and not force:
        print(f"DEM đã tồn tại: {output_file}")
        return output_file
    try:
        import elevation
    except ImportError as exc:
        raise ImportError("Cài thư viện: pip install elevation") from exc
    print(f"Đang tải SRTM theo bounds {DEM_BOUNDS}...")
    elevation.clip(bounds=DEM_BOUNDS, output=str(output_file))
    elevation.clean()
    if not output_file.exists():
        raise RuntimeError("Không tải được DEM.")
    print(f"Đã lưu DEM: {output_file}")
    return output_file

if __name__ == "__main__":
    download_dem()
